﻿Bare_bitcell:              File contains a single bitcell used in other files


Bitline_testing:          File used to test the power draw of charging the bitlines with different amounts of bitcells, currently configured for 64 bitcells. 


Wordline_testing:      File used to test the power draw of the wordlines with different amounts of words. Currently configured for 64 words.


block_sim:                File used to simulate a full block. Configured with the final dimensions: 1024 bitcells horizontally and 16 bitcells vertically. full_state1 is the simulation file used to simulate the final memory. 


TXDecoder4:16-newSO:        File contains the 1:16 decoder schematic 


TXDecoder6:64-newSO:         File contains the 1:64 decoder schematic


TX32bitMux32:5-newNEW:        File contains the 32 bit 32:1 multiplexer schematic 


TX32bitMux64:6-newNEW:         File contains the 32 bit 64:1 multiplexer schematic


testbench-TXDecoder4:16-newSO:        File contains the testbench used to test the 1:16 decoder


testbench-TXDecoder6:64-newSO:        File contains the testbench used to test the 1:64 decoder


testbench-TX32bitMux32:5-newNEW:        File contains the testbench used to test the 32 bit 32:1 multiplexer


testbench-TX32bitMux64:6-newNEW:        File contains the testbench used to test the 32 bit 64:1 multiplexer